frontend-nanodegree-arcade-game
===============================

To play the game, do the following:
1. Clone this repository
2. Navigate to your local copy of index.html through your web browser
3. Have fun playing!

**OR**

1. Play online [here](http://memerr.github.io/frogger/index.html)

# Playing the game

### Basic Movement

You can move the player up, down, left or right using the arrow keys.

### Game Objective

Get as many points as possible by jumping in the water as many times as possible without being touched by the bugs.

## TO DO

- Implement sounds
- Add a splash screen
- Add levels
- Add collectibles

Asset References
===============================

Royalty free sounds from [here](freesound.org)