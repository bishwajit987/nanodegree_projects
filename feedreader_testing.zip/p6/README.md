# Feed Reader Testing - UDACITY FEND Project 6

Project 6 for the Udacity Front-End Web Developer Nanodegree.

## Installation

1. Clone the Repo
2. Open index.html in your browser

## Technologies Used

* [Jasmine](http://jasmine.github.io/)
* [jQuery](http://jquery.com)

## References

* https://discussions.udacity.com/t/new-feed-changes-content-test/47601/4
* https://discussions.udacity.com/t/step-16-write-a-test-that-ensures-when-a-new-feed-is-loaded-by-the-loadfeed-function-that-the-content-actually-changes/20810
* https://discussions.udacity.com/t/what-does-this-mean-19-implement-error-handling-for-undefined-variables-and-out-of-bound-array-access/157343
